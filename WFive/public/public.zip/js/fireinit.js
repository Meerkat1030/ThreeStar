var firebaseConfig = {
  apiKey: "AIzaSyA0YoprDLXi00UOUdUAKNKXnsghKWUd8hU",
  authDomain: "wfive-79380.firebaseapp.com",
  databaseURL: "https://wfive-79380.firebaseio.com",
  projectId: "wfive-79380",
  storageBucket: "wfive-79380.appspot.com",
  messagingSenderId: "532640605802",
  appId: "1:532640605802:web:f5ff1262f3c58d45da0c13",
  measurementId: "G-2LXMKMZDNX"
};
firebase.initializeApp(firebaseConfig);
