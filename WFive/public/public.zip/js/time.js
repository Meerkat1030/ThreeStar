// 날짜 함수
var d = new Date();
   var year = d.getFullYear().toString();
   var month = (d.getMonth() + 1).toString();
   var day = d.getDate().toString();
   var hours = d.getHours().toString();
   var min = d.getMinutes().toString();
   var sec = d.getSeconds().toString();
   var currentTime = year + month + day + hours + min + sec;
